The file main_9_9_2.m shows how to test the SET algorithm.

LowRankMatrix03: produce a low rank matrix.
MatrixSET02: use the SET algorithm to solve the consistent matrix completion problem. 